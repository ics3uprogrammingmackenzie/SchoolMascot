﻿/*
 * Created by: Mackenzie Brown Plourde
 * Created on: 16 February 2019
 * Created for: ICS3U Programming
 * Assignment #2 - Falling Objects
 * This program...
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FallingObjectsMackenzieBrownPlourde
{
    public partial class frmObjectsFalling : Form
    {
        public frmObjectsFalling()
        { //Hiding the text befor program starts
            InitializeComponent();
            this.lblAnswer.Hide();
            this.lblHeight.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {//declaring variable
            double time,height;
            //Converting the string from text box to a double
                time = double.Parse(txtInput.Text);
            //Formula
            height = 100 - 9.81 * time * time;
           this.lblAnswer.Text = Convert.ToString(height) + "meters" ;
           //showing text at bottem of screen

            this.lblAnswer.Show();
            this.lblHeight.Show();
        }
    }
}
